import './comment.css';

import { useState, useEffect } from 'react';

export default Comment;