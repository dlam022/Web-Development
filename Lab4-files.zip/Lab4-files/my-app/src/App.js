import logo from './logo.svg';
import './App.css';

import NewPost from './NewPost/newPost';
import Comment from './Comment/comment';

import { useState, useEffect } from 'react';

function App() {
  
  const [comments, setComments] = useState([])

  const addComment = (comment) => {
    setComments([...comments, comment])
  }

  const addReply = (reply) => {

  }


  return (
    <div className="App">
      <header className="App-header">
        <div className="postContainer">
          <div id="title">
            New Post
          </div>
          <div id="namePost">
            <input type="text" placeholder="Name..."></input>
          </div>
          <NewPost addComment ={addComment}> </NewPost>
      </div>
      <div className="commentContainer">
        <input type="text"  placeholder="Write a new post..."></input>
        {comments.map((comment) => (
          <Comment addComment={addReply} comment={comment}></Comment>
        ))}
      </div>
      {/* <img src={logo} className="App-logo" alt="logo" /><p>
        Edit <code>src/App.js</code> and save to reload.
      </p><a
        className="App-link"
        href="https://reactjs.org"
        target="_blank"
        rel="noopener noreferrer"
      >
        Learn React
      </a></> */}
      </header>
    </div>
  );
}

export default App;
