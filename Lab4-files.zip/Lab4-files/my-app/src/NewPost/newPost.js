import './newPost.css';

import { useState, useEffect } from 'react';

import Buttom from '@mui/joy/Button'

const NewPost = ({addComment}) => {

}

export default NewPost;