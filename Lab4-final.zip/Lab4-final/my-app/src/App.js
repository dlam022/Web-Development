// some parts were guided by chatgpt
import './App.css';

// import NewPost from './NewPost/newPost';
import Comment from './Comment/comment';

// import { useState, useEffect } from 'react';
import { useState } from 'react'; // useEffect not used

function App() {
  const [comments, setComments] = useState([]);

  const addComment = (comment, username) => {
    setComments([...comments, { content: comment, username, replies: [] }]);
  };

  const addReply = (reply, parentId, depth) => {
    if (depth <= 3) { // if depth is no more than 3, ignore
      const updatedComments = [...comments];
      const parentComment = updatedComments[parentId];
      parentComment.replies.push({ ...reply, depth });
      setComments(updatedComments);
    }
  };

  const handlePostSubmit = (event) => {
    event.preventDefault();
    const postContent = event.target.elements.postContent.value;
    const postUsername = event.target.elements.postUsername.value;
    if (postContent.trim() !== '' && postUsername.trim() !== '') {
      addComment(postContent, postUsername);
      event.target.elements.postContent.value = '';
      event.target.elements.postUsername.value = '';
    }
  };

  return (
    <div className="App">
      <header className="App-header">
        <div className="postContainer">
          <div className="postStyle">
            <div id="title">
              <strong>New Post</strong>
            </div>
            <div id="namePost">
              {/* <input type="text" name="postUsername" placeholder="Your Name" /> */}
            </div>
            <div className="commentContainer">
            <form onSubmit={handlePostSubmit}>
              <input type="text" name="postUsername" placeholder="Your Name" />
              <input type="text" name="postContent" placeholder="Write a new post..." />
              <button class="submitButton" type="submit">Submit</button>
            </form>
          </div>

          <div className="newPost">

            {comments.map((comment, index) => (
              <div key={index}>
                <Comment
                  comment={comment.content}
                  username={comment.username}
                  depth={1}
                  addReply={(reply, depth) => addReply(reply, index, depth)}
                />

                <div className="nestedReplies">
                  {comment.replies.map((reply, replyIndex) => (
                    <Comment
                      key={replyIndex}
                      comment={reply.content}
                      username={reply.name}
                      depth={reply.depth}
                      addReply={(nestedReply, depth) => addReply(nestedReply, index, depth)}
                    />
                  ))}
                </div>
                <hr 
        style={{
            background: 'black',
            color: 'black',}}
            />
              </div>
            ))}
          </div>
          </div>
        </div>
        </header>
    </div>
  );
}

export default App;
