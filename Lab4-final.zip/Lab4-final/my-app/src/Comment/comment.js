import './comment.css';

import { useState } from 'react';


function Comment({ comment, username, addReply, depth }) {
    const [name, setName] = useState('');
    const [replyContent, setReplyContent] = useState('');
    const [showReplyInput, setShowReplyInput] = useState(false);
    const [counter, setCounter] = useState(0);

    const incrementCounter = () => {
        setCounter(counter + 1);
    }

    const decrementCounter = () => {
        setCounter(counter - 1);
    }
  
    const handleNameChange = (event) => {
      setName(event.target.value);
    };
  
    const handleContentChange = (event) => {
      setReplyContent(event.target.value);
    };
  
    const handleToggleReplyInput = () => {
      setShowReplyInput(!showReplyInput);
    };
  
    const handleSubmitReply = (event) => {
      event.preventDefault();
      if (name.trim() !== '' && replyContent.trim() !== '') {
        addReply({ name, content: replyContent}, depth+1);
        setName('');
        setReplyContent('');
        setShowReplyInput(false);
        // depthCounter = depth;
        console.log(depth);
        // console.log(showReplyInput)
      }

    };

  
    return (
      <div className={`comment depth-${depth}`}> 
      {/* <button className="replyButton" onClick={handleToggleReplyInput}>Reply</button> */}
        <div className="replyContainer">
          
            <p id="postName">
                <b>{username}</b> {comment}
            <div class="ratingCounter">
                <p>{counter}</p>
            </div>
            </p>
            <button 
                class="arrowUp"
                onClick={incrementCounter}>
            </button>
            <button 
                class="arrowDown"
                onClick={decrementCounter}>
            </button>
            {/* <div class="ratingCounter">
                <p id="counterStyle">{counter}</p>
            </div> */}
            {/* <button class={`button-${depth} replyButton `} onClick={handleToggleReplyInput}>Reply</button> */}
            {/* the thing below avoids button-3 since it doesn't exist */}
            <button class={`button-${depth > 1 ? 2 : 1} `} onClick={handleToggleReplyInput}>Reply</button> 
        </div>
        {showReplyInput && (
                <div class="commentContainers">
                    <form onSubmit={handleSubmitReply}>
                        <input type="text" value={name} onChange={handleNameChange} placeholder="Your Name" />
                        <input type="text" value={replyContent} onChange={handleContentChange} placeholder="Your Reply" />
                        <button class="submitButton" type="submit">Submit</button>
                        {/* <p id="verticalLine"></p> */}
                    </form>
                </div>
            )} 
         </div>
    );
  }


export default Comment;